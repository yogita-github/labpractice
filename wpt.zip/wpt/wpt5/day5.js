// function hello(){
//     console.log("hello");
// }
// hello();

// function show()
// {
//     console.log("something");
// }
// // function demo(args){
//     console.log(args);
//     args();
// }
// demo(show());

// show(function (){
//     console.log("hriwer");
// })

// const newfunc=()=>{
//     console.log("this is func");
// }
// newfunc();
// // function with single statement
// const func1 = ()=>console.log("helloo");
// func1();
// // function with single argument and single statement
// const func2 = a =>console.log(a*5);
// func2(5);
// // function with multiple args and multiple statements
// const func3 = (x,y)=>{
//     console.log(x*y);
//     console.log(x+y);
// }
// func3(4,7);
// // function with multiple args and single sttment 
// const func4 = (e,f)=>console.log(e/f);
// func4(9,3);



