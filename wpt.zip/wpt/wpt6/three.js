
function func1(){
    var info = document.getElementById('ok');
    console.log(info.innerHTML);
}
