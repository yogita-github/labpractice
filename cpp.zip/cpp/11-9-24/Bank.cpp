#include <iostream>

using namespace std;

class Bank{
	int id;
	long balance;
	int pin;
	
	public:
		Bank(int i,long b){
			this -> id = i;
			this -> balance = b;
			cout<<"Enter Pin : "<<endl;
			cin>>pin;
		}
		
		void balanceInquiry(){
			cout<<"Enter Pin :";
			int p;
			cin>>p;
			if(this -> pin == p){
				cout<<this ->balance<<endl;
			}else{
				cout<<"Invalid pin : "<<endl;
			}
		}
		
		void changePin(){
			int p;
			cout<<"Enter new Pin : ";
			cin>>p;
			this -> pin = p; 
		}
		
		void resetPin(){
			cout<<"Enter id to get OTP : "<<endl;
			int i;
			cin>>i;
			if(id == i){
				int p;
				cout<<"Enter old PIN : " <<1234;
				cin>>p;
				if(p == 1234){
					cout<<"Enter new PIN : ";
					cin>>pin;
					cout<<endl;
				}else{
					cout<<"Invalid original number "<<endl;
				}				
			}else{
				cout<<"Invalid OTP " <<endl;
			}
		}

};

int main(){
	Bank omen(1,50000);
	omen.balanceInquiry();
	return 0;
}
