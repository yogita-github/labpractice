#include<iostream>
using namespace std;

int lengthh(char* ch){
	int count = 0;
	while(*ch != '\0'){
		ch++;
		count++;
	}
	return count;
}

void copy(char* ch1,char* ch2){
	
	while(*ch2 != '\0'){
		*ch1 = *ch2;
		ch1++;
		ch2++;
	}
}

void concatt(char* ch1,char* ch2){
	while(*ch1 != '\0'){
		ch1++;
	}
	while(*ch2 != '\0'){
		*ch1 = *ch2;
		ch1++;
		ch2++;	
	}	
	*ch1='\0';
}

void reverse(char* ch){
	int i =0;
	int j = lengthh(ch) -1;
	
	while(i < j){
		int temp = ch[i];
		ch[i++] = ch[j];
		ch[j--] = temp;
	}	
}

bool pl(char* ch){
	
	int i =0;
	int j = lengthh(ch) -1;
	
	while(i<j){
		if(ch[i++] != ch[j--]){
			return false;
		}	
	}
	return true;
}

bool compare(char* ch1, char* ch2){
	
}

int main()
{
	char ch[40]="abbad";
	char ch1[5];
	if( pl(ch)){
		cout<<"True";
	}else{
		cout<<"False ";
	}
}
