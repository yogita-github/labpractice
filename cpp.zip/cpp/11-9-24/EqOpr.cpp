#include <iostream>
#include <cstring>
using namespace std;

class A{
	int size;
	char* pointer;
	
	public:
		A(char* a){
			int size = strlen(a);
			pointer = new char[size];
			strcpy(pointer,a);
		}
		
		void show(){
			cout<<"Name is : " <<this -> pointer <<"    " <<&pointer <<endl ;
		}
		~A(){
			delete pointer;
			cout<<"Dest " <<endl;
		}
		
};


int main(){
	A a("Someone");
	a.show();
	
	{
		A a1(a);
		a1.show();		
	}

	
	return 0;
}
