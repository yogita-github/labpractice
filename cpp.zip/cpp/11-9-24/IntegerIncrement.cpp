#include <iostream>
using namespace std;

class Complex{
	int real,img;
	
	public:
		Complex(int a,int b) : real(a), img(b) {}
		Complex(){}
		//post increment coz of int
		Complex operator++(int){
			Complex temp = *this;
			++this->real;
			++this->img;
			return temp;
		}
		
		Complex operator++(){
			++this->real;
			++this->img;
			return *this;
		}


		Complex operator--(int){
			Complex temp = *this;
			--this->real;
			--this->img;
			return temp;
		}
		
		Complex operator--(){
			--this->real;
			--this->img;
			return *this;
		}
		
		void show(){
			cout<<real <<" + "<<img <<"i"<<endl;
		}
};
int main(){
	Complex c1(10,20);
	cout<<"c1 : ";
	c1.show();
	
	Complex c2 = c1++;
	cout<<"Post increment from c1 & c2 is : ";
	c2.show();


	Complex c3 = c2--;
	cout<<"Post decrement from c2 & c3 is : ";

	c3.show();	
	
	Complex c4 = --c3;
	cout<<"Pre decrement from c3 & c4 is : ";

	c4.show();
	return 0;
}
