#include <iostream>
using namespace std;

class A{
	int a;
	public:
		A(int number){
			this -> a = number;
			cout<<this<<endl;
		}
		void show(){
			cout<<this -> a<<"  " <<this <<"  "<<endl;
		}
};

int main(){
	A a1(10);
	a1.show();
	cout<<&a1<<endl;
	
	A b1(200);
	b1.show();
	cout<<&b1;
}
