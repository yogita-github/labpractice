#include <iostream>
#include <cstring>
using namespace std;

int main(){
	char* array[5] = {"Oneee", "Twooow","Thirdd","Fourrrrrrr","Fiveeeeee"};
	for(int i =0; i < 5; i++){
		
		for(int j =0; j <strlen(array[i]);j++){			
			cout<<* (*(array+i) + j )<<"  ";
		}
		cout<<endl;
	}
	
	return 0;
}
