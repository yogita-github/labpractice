#include <iostream>
#include <cstring>
using namespace std;

class Complex{
	int len;
	char* pointer;
	
	public:
		Complex(char* ch){
			int len = strlen(ch);
			pointer = new char[len];
			strcpy(pointer,ch);
		}
		
		Complex operator=(Complex& c){
			cout<<"Assignment operator " <<endl;
			 len = strlen(c.pointer);
			 pointer = new char[len + 1];
			strcpy(pointer,c.pointer);			
			return *this;	
		}
		
		~Complex(){
			delete pointer;
			cout<<"Dest " <<endl;
		}
		
		void show(){
			cout<<pointer <<endl;
		}
};

int main(){
	Complex a1("sOMEONEE");
	a1.show();
	
	Complex c2(a1);
	c2.show();
	
	Complex c3("idontknow");
	c3.show();
	
	c2 = c3;//c2.operator=(c3)
	c2.show();
	
	return 0;
}
