#include <iostream>

class Base {
public:
    virtual void show() {
        std::cout << "Base class show function" << std::endl;
    }
    virtual ~Base() {}
};

class Derived : public Base {
public:
    void show() override {
        std::cout << "Derived class show function" << std::endl;
    }
};

class Complex {
private:
    double real;
    double imag;
public:
    Complex(double r = 0, double i = 0) : real(r), imag(i) {}

    Complex operator + (const Complex &other) const {
        return Complex(real + other.real, imag + other.imag);
    }

    void display() const {
        std::cout << "Real: " << real << " Imag: " << imag << std::endl;
    }
};

int main() {
	
    Base *b;
    Derived d;
    b = &d;
    b->show();

    Complex c1(1.2, 3.4);
    Complex c2(5.6, 7.8);
    Complex c3 = c1 + c2;
    c3.display();

    return 0;
}

