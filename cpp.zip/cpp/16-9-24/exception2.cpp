#include <iostream>
using namespace std;

class MyException : public exception{
	public:
		void what(){
			cout<<"Wrong values : " <<endl;
		}
};

int main(){
	try{
		MyException e;
		throw e;
	}
	catch (MyException e){
		e.what();
	}
}
