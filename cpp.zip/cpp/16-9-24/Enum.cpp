#include <iostream>
using namespace std;

enum RatingGrades{
	A='z',
	B='y',
	C='x'

//bad=4,good=6,okay=5
};
int main(){
	RatingGrades i;
	i = A ;
	cout<<i;
}
