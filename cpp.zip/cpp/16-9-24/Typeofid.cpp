#include<iostream>
#include<typeinfo>
using namespace std;

class A{
	public:
	virtual void show(){
		cout<<"Inside class A "<<endl;
	}
};

class B : public A{
	public:
	void show(){
		cout<<"Inside class B "<<endl;
	}
};

int main(){
	B object;
	A* pointerBase = &object;
	cout<<typeid(pointerBase).name()<<endl;
	cout<<typeid(*pointerBase).name()<<endl;
	
	return 0;
}
