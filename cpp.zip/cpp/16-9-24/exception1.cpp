#include <iostream>
using namespace std;

int main(){
	int a;
	int b;
	cout<<"Enter value : "<<endl;
	cin>>a;
	cin>>b;
	
	try{
		if(b==0)
		{
		throw b;
		}else{
			cout<<a/b;
		}
	}
	catch(int e){
		cout<<"Numerator is  : "<<e;
	}	
}
