#include <iostream>
using namespace std;

int main(){
	typedef int numberss;
	
	numberss a = 10;
	numberss b = 20;
	cout<<a + b<<endl;
	
	typedef char alpha;
	alpha m = 'Z';
	alpha n = 'A';
	
	cout<<"m is : "<<m <<"  &  n is : "<<n;
}
