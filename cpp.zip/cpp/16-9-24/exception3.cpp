#include <iostream>
#include <stdexcept> 
using namespace std;

int main(){
	
	try{
		throw "Not Found";
	}
	catch(...){
		try{
			throw;
		}
		catch(const char* ch){
			cout<<"Error is : " <<ch<<endl;
		}
	}
}
