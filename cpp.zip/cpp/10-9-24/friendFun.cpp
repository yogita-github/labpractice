#include <iostream>
using namespace std;

class A{
	int real;
	int img;
	
	public:
		A(int a,int b){
			real = a;
			img = b;
		}
	
		friend void show(A& a){
			cout<<"inside class A && values are : " << a.real <<" + " << a.img <<"i" <<endl;
		}
};

class B{
	int real;
	int img;
	char ch;
	
	public:
		B(int a,int b,char c){
			this -> real = a;
			this -> img = b;
			this -> ch = c;
		}
		B(){
		}
		friend void show(B &a){
			cout<<"inside class B && values are : " << a.real <<" + " << a.img <<"i" <<" grade is : " << a.ch <<endl;
		}
};


int main(){
	A a1(10,20);
	B b1(100,200,'A');
	
	show(a1);
	show(b1);
	
	
	return 0;
}
