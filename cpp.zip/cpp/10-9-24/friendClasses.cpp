#include <iostream>
using namespace std;

class A{
	protected :
	int a;
	int b;
	
	public :
		A(){
		}
		A(int p,int q){
			this -> a = p;
			this -> b = q;
		}
	
	friend class B;
};

class B{
	
	public :
		show(A& aa){
			cout<<aa.a<<" "<<aa.b;
		}
};

int main(){
	A a1(20,30);
	B b1;
	
	b1.show(a1);
	
	return 0;
}
