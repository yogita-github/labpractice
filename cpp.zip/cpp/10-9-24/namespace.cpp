#include<iostream>
using namespace std;

namespace employee{
	class A{
		private:
		int sal;
		protected:
		int job;
		public:
			A(){
				 sal = 80000;
				 job = 70000;
			}
			void show()
			{
				cout<<"Salary is: "<<sal<<endl;
				cout<<"Job is : "<<job<<endl;
			}
	};
	
	void show()
			{
				int sal = 80000;
				int job = 70000;
				cout<<"Salary is: "<<sal<<endl;
				cout<<"Job is : "<<job<<endl;
			}
}
int main()
{
	employee ::A obj;	
	obj.show();
	
	employee::show();
	
}
