#include<iostream>
using namespace std;

class Rutu{
	private:
		int private_sal;
	protected:
		int protected_sal;
	public:
		Rutu()
		{
			private_sal = 6700;
			protected_sal = 5600;
		}
		friend class sarvi;
	};
class sarvi{
	public:
		void display(Rutu& secret)
		{
			cout<<"Private Salary is: "<<secret.private_sal<<endl<<"Protected Salary is : "<<secret.protected_sal<<endl;
		}
};
int main()
{
	Rutu R;
	sarvi S;
	S.display(R);
}


