#include<iostream>
using namespace std;

class first;

class second{
	public:
	void memf(first&);
};

class first{
	private:
		int privhobby;
	protected:
		int protwork;
		public:
			first()
			{
				privhobby= 45;
				protwork = 78;
			}
			friend void second:: memf(first&);
};

void second::memf(first& t){
	cout<<"Private hobby is: "<<t.privhobby<<endl;
	cout<<"Protected work is : "<<t.protwork<<endl;
}

int main()
{
	first f1;
	second s1;
	s1.memf(f1);
}
