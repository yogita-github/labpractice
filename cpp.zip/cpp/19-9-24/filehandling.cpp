#include <iostream>
#include <fstream>
#include <string>  // Use string from <string> for better practice
using namespace std;

int main() {
    // Try to open the input file
    ifstream input_file("nine.txt");
    if (!input_file) {
        cout << "File not found." << endl;
    } else {
        cout << "Contents of the file:" << endl;
        string line;

        // Read and display the contents of the file
        while (getline(input_file, line)) {
            cout << line << endl;
        }
        input_file.close();  // Close the input file
    
	}
}
