//stl
#include <iostream>
using namespace std;
#include <vector>

int main(){
	vector<int> arl;
	for(int i =0; i < 10; i++){
		arl.insert(i);
	}
	for(int i = arl.begin() ; )
}
