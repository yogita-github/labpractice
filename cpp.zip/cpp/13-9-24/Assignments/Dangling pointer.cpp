#include<iostream>
using namespace std;
class As{
	public:
	 int a;
	 char *ptr;
	 public:
	 	As(){
		a=12;
	 	ptr=new char;
	 	*ptr='s';
	 	}
	 	void show(){
	 		cout<<a<<endl;
			cout<<*ptr<<endl;	 		
		 }
		~As(){
			delete ptr;
			
		}
};
int main(){
	As a;
	a.show();
	{
	As a2(a);
	a2.show();
}
 	
a.show();

}
