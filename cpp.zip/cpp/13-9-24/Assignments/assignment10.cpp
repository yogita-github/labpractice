#include <iostream>
#include <cstring>
#include <cctype>  // For isalnum()

using namespace std;

void removed(char* ch) {
    char* pointer = ch;  
	int len = strlen(ch);
	
    for (int i = 0; ch[i] != '\0'; i++) {

        if ( ch[i]  ) {
            *pointer++ = ch[i]; 
        }
        
    }
    *pointer = '\0';  

}

int main() {
    char name[] = "Yogesh@123*&^$%";
    
	removed(name);
    cout << "Modified string: " << name << endl;
    
    return 0;
}

