//7.Write a template function swap () to swap the variables of int, char and complex types
#include <iostream>
using namespace std;

template<class A>
void swapp(A& a, A&b)
{
	A temp = a;
	a = b;
	b = temp;
}

int main(){
	char a = 'A';
	char b = 'Z';
	swapp(a,b);
	cout<<"A is : " << a << " and B is : " << b <<endl;
}
