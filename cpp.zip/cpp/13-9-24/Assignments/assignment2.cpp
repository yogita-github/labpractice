//WRITE A CPP PROGRAM TO CHECK WHETHER THE GIVEN NUMBER IS PALINDROM OR NOT.
#include <iostream>
#include<cstring>
using namespace std;

bool compare(int,int);

int main(){
	int n;
	cout<<"Enter the number : ";
	cin>>n;
	int m = n;
	
	
	int reversed = 0;
	while(m > 0){
		int rem = m % 10;
		m = m / 10;
		reversed = reversed * 10 + rem;
	}
	
	
	if(compare(n,reversed)){
		cout<<"Truee ";
	}else{
		cout<<"false ";
	}
		
}

bool compare(int a,int b){
	while(a > 0){
		if(a % 10 != b % 10){
		return false;
		}	
		a = a / 10;
		b = b / 10;
	}
	return true;
}
