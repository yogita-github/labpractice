#include <iostream>
using namespace std;

class A{
	public:
		static void show(){
			cout<<"isnide A"<<endl;
		}
};

class B{
	public:
		static void show(){
			cout<<"isnide B"<<endl;
		}
};

int main(){
	A::show();
	B::show();
}
