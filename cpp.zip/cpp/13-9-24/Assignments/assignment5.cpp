//5)WRITE A CPP PROGRAM TO DISPLAY SUMMATION OF  EVEN AND ODD NUMBERS IN AN ARRAY OF INTEGERS.
#include<iostream>
using namespace std;
int main()
{
	int sum_even=0;
	int sum_odd=0;
	int arr[10]={1,2,3,4,5,6,7,8,9,0};
	for(int i=0;i<10;i++)
	{
		
		if(arr[i]%2==0){
			sum_even+=arr[i];
		}
		else{
			sum_odd+=arr[i];
		}
	}
	cout<<sum_even<<endl;
	cout<<sum_odd<<endl;
}

