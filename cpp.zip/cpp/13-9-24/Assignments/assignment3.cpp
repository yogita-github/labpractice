//3)WRITE A CPP PROGRAM TO DISPLAY 1ST 25 PRIME NUMBER.
#include <iostream>
using namespace std;

bool isPrime(int n){
	if(n % 2 == 0) return false;
		
	for(int i = 3; i < n ; i++){
		if(n % i == 0) return false;
	}
	return true;
}

int main(){
	cout<<"Prime numbers are : 2 ";
	int number = 3;
	int count = 1;
	
	while(count < 25){	
	
		if(isPrime(number)){
			cout<<number <<" ";
			count++;
		}	
			
		number++;
	}	
	
	cout<<endl<<"Count is : "<<count;
}

