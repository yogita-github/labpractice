//6)WRITE A CPP PROGRAM TO CHANGE THE CASE OF EACH CHARACTER IN A GIVEN STRING.
#include <iostream>
#include <cstring>
using namespace std;

char toLowerCase(char ch){
	if(ch == ' ') return ' ';
	if(ch+'0' < 97+47){
		return ch + 32;
	}else{
		return ch;
	}
	return '0';
}

char toUpperCase(char ch){
	if(ch+'0' > 97+47){
		return ch - 32;
	}else{
		return ch;
	}
	return '0';
}
int main(){
	
	string ch = "FUNCTION TO CONVERT TO LOWER CASE";
	
	for(int i =0; i < 34; i++){
		cout<<toLowerCase(ch[i]);
	}
	cout<<endl;
	
	string name = "ok it is a function for upper case";
	int l1 = sizeof(name);
	for(int i =0; i <34; i++){
		cout<<toUpperCase(name[i]);
	}
	
}
