//4)WRITE A CPP PROGRAM TO DISPLAY FACTORIAL FROM NUMBER 5 TO 8.

#include<iostream>
using namespace std;

int main()
{
	int n =5;
	while(n<=8)
	{
		int factorial=1;
		for(int i=1;i<=n;i++)
		{
			factorial = factorial*i;
			
		}
		cout<<"Factorial "<<n<<" is: "<<factorial<<endl;
		n++;
	}
}
