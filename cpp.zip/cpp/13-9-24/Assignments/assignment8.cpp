//8)C++ Program to Find number of Digits in any number
#include  <iostream>
using namespace std;

int main(){
	int num;
	cout<<"Enter number : ";
	cin>>num;
	int count = 0;
	
	while(num > 0){
		num /= 10;
		count++;
	}
	cout<<"number of digits in Number is : "<<count;	
}
