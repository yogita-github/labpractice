//1)WRITE A CPP PROGRAM TO SWAP 2 VARIABLES WITHOUT USING 3RD VARIABLE./
#include<iostream>
using namespace std;

int main()
{
	int a=34,b=56;
	a = b ^ a;
	b = a ^ b ;
	a = b ^ a ;
	
	cout<<"Value of a is: "<<a<<endl;
	cout<<"Value of b is: "<<b<<endl;
}
