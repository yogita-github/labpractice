//9)C++ Program to Reverse a Number
#include<iostream>
using namespace std;

int main(){
	
	int num;
	cout<<"Enter number to reverse : ";
	cin>>num;
		
	int reversed = 0;
	while(num > 0){
		int rem = num % 10;
		num /= 10;
		reversed = reversed * 10 + rem;
	}
	cout<<"Reversed number is : "<<reversed;
	
}
