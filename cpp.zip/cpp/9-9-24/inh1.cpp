#include <iostream>
using namespace std;

class A {
    int a;

public:
    A(int a) : a(a) {
        cout << "Constructor of A called " << endl;
    }

    A() : a(0) {
    }

    void show() {
        cout << a << endl;
    }
};

class B : virtual public A {
    int b;

public:
    B(int b) : A(0), b(b) { // A's constructor is called with a default value
        cout << "Constructor of B Called " << endl;
    }

    B() : A(0), b(0) {
    }

    void show() {
        cout << b << endl;
    }
};

class C : virtual public A {
    int c;

public:
    C(int a, int c) : A(a), c(c) {
        cout << "Constructor of C Called " << endl;
    }

    C() : A(0), c(0) {
    }

    void show() {
        cout << c << endl;
    }
};

class D : public C, public B {
    int d;

public:
    D(int a, int b, int c, int d) : A(a), C(a, c), B(b), d(d) {
        cout << "Constructor of D Called " << endl;
    }

    void show() {
        cout << d << endl;
    }
};

int main() {
    D Object(10, 20, 30, 40);
    cout << endl << "Size of A is : " << sizeof(A) << endl;
    cout << "Size of B is :" << sizeof(B) << endl;
    cout << "Size of C is :" << sizeof(C) << endl;
    cout << "Size of D is :" << sizeof(D) << endl;
    Object.A::show();
    return 0;
}

