#include <iostream>
using namespace std;
class Employee{
	int id;
	int sal;
	
	public:
		Employee(int identity,int sales)
		{
			this->id=identity;
			this->sal=sales;
			cout<<"Inside constructor"<<endl;
		}
		Employee()
		{
		}		
		virtual void show(){
			cout<<"Calling from Employee class : id is : " <<id <<"Salary is : " << sal <<endl ; 
		}
};

class WageEmployee:virtual public Employee{
	int rsPerHr;
	
	public:
		WageEmployee(int rs)
		{
			this->rsPerHr=rs;
		}
		WageEmployee()
		{
		}
		void show(){
			cout<<"Calling from WageEmployee class : rsPerHr are : " <<rsPerHr <<"rs "<<endl ; 
		}
};

class SalesEmployee:virtual public Employee{
	int salesEmpId;
	int salesPerMnt;
	public:
	SalesEmployee(int SalesEmpId,int sal)
		{
			this-> salesEmpId = SalesEmpId;
			this-> salesPerMnt = sal;
			cout<<"Inside constructor3" <<endl ;
		}
		SalesEmployee()
		{
		}
		void show(){
			cout<<"Calling from SalesEmployee class : salesEmpId is : " <<salesEmpId <<"Sales salesPerMontyh are : " << salesPerMnt <<endl ; 
		}
};

class SalesManager : public SalesEmployee , public WageEmployee {
	public:
		SalesManager(int id,int sal,int rsPerHr,int salesEmpId,int salesPerMnt) 
			: SalesEmployee( salesEmpId ,salesPerMnt) :  WageEmployee(rsPerHr) :  Employee(id,sal);
		SalesManager()
		{
		}
		void showIncome(){
			cout<<"Income is : " << rsPerHr * (salesPerMnt* 0.1) + sal<<endl;
		}
};

int main(){
	SalesManager Employee1(1,20000,350,101,10000);
	Employee* pointer = &Employee1;
	
	return 0;
}
