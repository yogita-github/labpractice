#include<iostream>
using namespace std;

class A{
	int a;
	public :
		A(int p){
			a = p;
		}
		A(){
		}
		virtual void show(){
			cout<<"from a : " <<a <<endl;
		}
		void sqr(){
			cout<<"from a : " <<a * a <<endl;
		}
};
class B : public A{
	int b;
	public :
		B(int a,int b) : A(a){
			this -> b = b;
		}
		B(){
		}
		void show(){
			cout<<"From b : " <<b<<endl;
		}
		void sqr(){
			cout<<"From b : " << b*b <<endl;
		}
};

int main(){
	B Obj(10,20);
	A* pointer = &Obj;
	pointer -> show();
	pointer -> sqr();
	return 0;
}
