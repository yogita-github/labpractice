#include<iostream>
using namespace std;

class Base{
	public:
	virtual void function1()
	{
		cout<<"Base class - We are in function 1 "<<endl;
	}
	virtual void function2()
	{
		cout<<"Base class - We are in function 2"<<endl;
	}
	virtual void function3()
	{
		cout<<"Base class - We are in function 3"<<endl;
	}
};

class Derived1: public Base{
	public:
		void function1()
		{
			cout<<"From derived1 class : First function"<<endl;
		}
};

class Derived2: public Base{
	public:
		void function2()
		{
			cout<<"From derived2 class : Second function"<<endl;
		}
};

int main()
{
 	Base* pointer1 = new Base(); 
    Base* pointer2 = new Derived1(); 
    Base* pointer3 = new Derived2(); 
    
	pointer1 -> function1();
	pointer1 -> function2();
	pointer1 -> function3();
	pointer2 -> function1();
	pointer2 -> function2();
	pointer2 -> function3();
	pointer3 -> function1();
	pointer3 -> function2();
	pointer3 -> function3();
}


