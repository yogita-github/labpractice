#include <iostream>
using namespace std;

class Car{

	protected:
		int price;
		int model;
	
	public:
		Car(int p, int m){
			this -> price = p;
			this -> model = m;
		}
		Car(){}
		~Car(){
		//	cout<<"Destructor called for Car Class " <<endl;
		}
		virtual void showInfo()=0;
};

class Honda : public Car{
	string country;
	int tax;
	
	public:
		Honda(int p,int m,string c,int t) : Car(p,m){
			this -> country = c;
			this -> tax = t;
		}
		Honda(){}
		void showInfo(){
			cout<<"Honda Car from "<<this -> country <<" model " << model <<" price is : " << price + (price*this->tax/100)<<endl;
		}
};

class Tata : public Car{
	string country;
	int tax;
	
	public:
		Tata(int p,int m,string c,int t) : Car(p,m){
			this -> country = c;
			this -> tax = t;
		}
		Tata(){}
		void showInfo(){
			cout<<"TATA Car from "<<this -> country <<" model " << model <<" price is : " << price + (price*this->tax/100)<<endl;
		}
};
class Useless : public Car{
	int okk;
	int sure;
	
	public:
		Useless(int a,int b){
			this -> okk = a;
			this -> sure = b;
		}
		Useless(){
		}
};

int main(){
	Honda HondaCar1(2500000,2024,"Germany",37);
	HondaCar1.showInfo();	
	
	Tata tataCar1(900000,2023,"India",28);
	tataCar1.showInfo();
	
	//error for uselessCar coz pure virtual function not declared inside it so it will also become abstract class like its base class 'Car'
	Useless u1(10,20);
	
	return 0;
}
