#include <iostream>
using namespace std;

class A{
	protected :
	int a;
	int b;
	
	public:
		A(){}
		
		A(int,int);
		
		 void show(){
			cout<<"returning from A :" << a <<" & " << b;
		}
};

A::A(int a,int b){
	this -> a = a;
	this -> b = b;
}

class B : public A{
	int c;
	
	public :
		B(int,int,int);
		B(){
		}
	
	void show(){
	cout <<" calling show from B \n" << a << " & " <<b << " & " << c;
	}
};

B::B(int a,int b,int c) : A(a,b){
	this -> c = c;
}

int main(){
	A* ptr; 
	B b1(3,4,5);
	ptr = &b1;
		
	ptr -> show();
	
	return 0;
}
