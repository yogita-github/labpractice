#include <iostream>
#include <cstring>
using namespace std;

int main(){
	cout<<"Enter the size of arr : ";
	
	int n;
	cin>>n;
	//on heap
	int* arr = new int[n];
	
	cout<<"Enter the " <<n <<"vlaues inside array" <<endl;
	
	for(int i =0; i < n; i++){
		cin>>*(arr+i);
	}
	cout<<endl;
	cout<<"Your array is : "<<endl;
	for(int i =0; i < n; i++){
		cout<<*(arr+i) <<" ";
	}
	cout<<endl;
	return 0;
	
}
