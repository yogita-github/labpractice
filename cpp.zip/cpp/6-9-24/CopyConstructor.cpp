//copy constructor
#include <iostream>
using namespace std;

class A{
	int size;
	int* pointer;
	
	public:
		A(int l){
			this -> size = l;
			this -> pointer = new int[size];
			cout<<"Enter values for array on heap : " <<endl;
			for(int i = 0; i < this -> size; i++){
				cin>>*(pointer + i);
			}
		}
		void show(){
			
			cout<<"Array is : ";
			
			for(int i = 0; i < this -> size; i++){
				cout<<pointer[i] <<" ";
			}
			cout<<endl;
		}
		
		A(A &b){
			this ->size = b.size;
			this -> pointer = new int[size];
			for(int i =0; i < b.size; i++){
				*(pointer + i ) = *(b.pointer + i);
			}
		}
		~A(){
			delete pointer;
			pointer = NULL;
			cout<<"destructor is called & deleted memory from heap " <<endl;
		}
};

int main(){
	A a1(5);
	
	cout<<endl;
	a1.show();
	
	{
		A a2(a1);
		cout<<endl;
		a2.show();
	}
	cout<<endl;
	a1.show();

	return 0;
}
