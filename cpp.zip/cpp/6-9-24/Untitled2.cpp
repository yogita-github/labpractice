#include <iostream>
using namespace std;

class A{
	int a;
	public:
		A(int a){
			this -> a = a;
			cout<<"Constructor A " <<endl;
		}
		//virtual void show() = 0;
		void show() {
		return 	 ;
		}
		~A(){
			cout<<"D A" <<endl;
		}
};

class B : public A{
	int b;
	public:
		B(int a,int b) : A(a){
			this -> b = b;
			cout<<"Constructor B" <<endl;
		}
		void show() {
			cout << "val inside B is : " << b;
		}
		~B(){
			cout<<"D B" <<endl;
		}
};
class C : public B{
	int c;
	public:
		C(int a,int b,int c) : B(a,b){
			this -> c = c;
			cout<<"Constructor C" <<endl;
		}
		
		void show() {
			cout << "val inside C is : " << c;
		}
		~C(){
			cout<<"D C" <<endl;
		}
};
int main(){
	//A obj; //Abstract class
	//if virtual- type of obj else type of pointer 
	B* ptr;
	C obj(1,2,3);
	ptr = &obj;
	
	ptr -> show();
	cout<<endl;
	return 0;
}
