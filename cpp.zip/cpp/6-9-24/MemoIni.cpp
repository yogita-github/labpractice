#include <iostream>
#include <string.h>
using namespace std;

class A{
	int size;
	char* pointer;
	
	public:
		A(char *);
		void show(){
			cout<<"Size is : " <<size  <<endl <<"Name is :" <<pointer;
		}
};

A::A(char* ch){
	this -> size = strlen(ch);
	pointer = new char[size];
	strcpy(pointer,ch);
}

int main(){
	
	A a1("yogeshh");
	a1.show();		
	return 0;
}
