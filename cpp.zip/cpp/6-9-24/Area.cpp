#include <iostream>
using namespace std;

class Shapes{
	public:
		Shapes(){}
		virtual void area () = 0;
};

class Circle : public Shapes{
	int r;
	public :
		Circle(int r){
			this ->  r =r ;
		}
		void area(){
			cout<< (double)(22/7) * r * r<<endl;
		}
};

class Triangle : public Shapes{
	int l;
	int b;
	public :
		 Triangle(int l, int b){
			this ->  l = l ;
			this -> b=b;
		}
		void area(){
			cout<< (float)1/2 *l * b<<endl;
		}
};

class Square : public Shapes{
	int side;
	public :
		 Square(int side){
			this -> side = side ;
		}
		
		void area(){
			cout<<side*side<<endl;
		}
};

class Rectangle : public Shapes{
	int length;
	int breadth;

	public :
		Rectangle(int length,int breadth){
			this -> length = length ;
			this -> breadth = breadth;
		}
		
		void area(){
			cout<<length*breadth<<endl;
		}
};

int main()
{
	Circle c1(3);
	Square s1(5);
	Triangle t1(4,6);
	Rectangle r1(7,3);
	c1.area();
	s1.area();
	t1.area();
	r1.area();
}
