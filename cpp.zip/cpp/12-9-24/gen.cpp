#include <iostream>
using namespace std;

template <class A, class B>
class Clz {
    A a;
    B b;

public:
    Clz(A aa, B bb) : a(aa), b(bb) {}
    Clz() : a{}, b{} {} 
    void show() const {
        cout << "A: " << a << ", B: " << b << endl;
    }
};

int main() {
	Clz<int,int>a1(10,20);
	a1.show();
	
	
    return 0;
}
