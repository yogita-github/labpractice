#include<iostream>
using namespace std;


class Std{
	string name;
	int rollno;
	int marks[5];
	public:
		Std()
		{
			cout<<"Enter name of students: ";
			cin>>name;
			cout<<"Enter roll no: ";
			cin>>rollno;
			cout<<"Enter marks of 5 subjects: ";
			for(int i=0;i<5;i++)
			{
				cin>>marks[i];
			}
			
		}
		void show()
		{
			cout<<name<<" "<<rollno<<" "<<endl;
			for(int i=0;i<5;i++)
			{
				cout<<marks[i]<<" ";
			}
		}
};
int main()
{
	Std s1[2];
	
	for(int i=0;i<2;i++)
	{
		s1[i];
	}
	for(int i=0;i<2;i++)
	{
		s1[i].show();
		cout<<endl;
	}
}
